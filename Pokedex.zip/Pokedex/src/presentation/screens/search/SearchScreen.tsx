import { Text, View } from 'react-native';

export const SearchScreen = () => {
  return (
    <View>
      <Text>SearchScreen</Text>
      
    </View>
  )
}